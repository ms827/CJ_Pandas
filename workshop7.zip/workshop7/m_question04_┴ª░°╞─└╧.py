
import pandas as pd
import numpy as np

user_usage = pd.read_csv("./data/user_usage.csv")
user_device = pd.read_csv("./data/user_device.csv")
devices = pd.read_csv("./data/android_devices.csv")

### 코드 구현 ######
result = pd.merge(user_usage,
                  user_device[['use_id', 'platform', 'device']],
                  on='use_id',how='outer',indicator=True)
print(result)
print("1. merge한 전체 dimensions: {}".format(result.shape))
print("2. null 값을 가진 행의 개수: {}".format((result.apply(lambda  x : x.isnull().sum(), axis=1) != 0).sum()))
print((result.isnull().sum(axis=1)!=0).sum())
### 코드 구현 ######


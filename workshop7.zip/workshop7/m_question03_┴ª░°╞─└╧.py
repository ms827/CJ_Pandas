
import pandas as pd
import numpy as np

user_usage = pd.read_csv("./data/user_usage.csv")
user_device = pd.read_csv("./data/user_device.csv")
devices = pd.read_csv("./data/android_devices.csv")


### 코드 구현 ######
result = pd.merge(user_usage,
                  user_device[['use_id', 'platform', 'device']],
                  on='use_id',how='right')
print("1. result 데이터프레임: \n", result.head())
print("2. user_device 데이터프레임의 dimensions: {} \n".format(user_device.shape))
print("3. result 데이터프레임의 dimensions: {} \n".format(result.shape))
print("4. result 데이터프레임의 'monthly_mb'  컬럼에서 NaN값의 총개수:{} ".format(result['monthly_mb'].isnull().sum()))
print("5. result 데이터프레임의 'platform'  컬럼에서 NaN값의 총개수:{} ".format(result['platform'].isnull().sum()))
### 코드 구현 ######

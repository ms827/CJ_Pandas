

import pandas as pd
import numpy as np

df = pd.read_csv('../../../PycharmProjects/PandaProject/workshop/data/sample_data.csv', index_col=0)
print(df)
### 코드 구현 ######
# print(df.head(1))
# print(df.tail(1))
print("1. 인덱스 정보: \n", df.index)
print("2. 컬럼 정보: \n", df.columns)
print("3. 값 정보: \n", df.values)
### 코드 구현 ######
